package com.example.demo;


import org.json.JSONException;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceController
{
    @Autowired
    private ConverterService ConverterService;

    @CrossOrigin(origins = "*", allowedHeaders="*") 
    @GetMapping(value="Num2Word")
    public JSONObject control(@RequestParam("Num")String num)throws JSONException
    {

        return ConverterService.getResult(num);

    }
}
