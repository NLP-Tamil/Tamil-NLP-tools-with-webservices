package com.example.demo;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class ConverterService
{
    public JSONObject getResult(String num) throws JSONException
    {
        Converter convert = new Converter();
        String result = convert.getNumber(num);

        JSONObject number = new JSONObject();
        number.put("Number",result);

        return  number;

    }


}