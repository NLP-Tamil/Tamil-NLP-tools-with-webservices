package com.example.demo;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Service
public class N2W_Service {
	public JSONObject  getObject(String input)
	{
		JSONObject obj = new JSONObject();
		NumbersToTamilWords numbersToTamilWords = new NumbersToTamilWords();
	    //String input = "0";
	    if (input.length() <= 18) 
	    {
	        String number = numbersToTamilWords.convert(input);
	        System.out.println(number);
	        obj.put("Number", number);
	        
	    } 
	    else
	    {
	        System.out.println("தவறான உள்ளீடு ");
	        obj.put("Number", "தவறான உள்ளீடு ");
	    }
	    
	    return obj;
	}
    
}
