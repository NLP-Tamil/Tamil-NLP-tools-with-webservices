package com.example.demo;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
    @Autowired
	private N2W_Service serv;
    
    @CrossOrigin(origins = "*", allowedHeaders="*") 
	@GetMapping(value = "number2wordsTa")
	public JSONObject getString(@RequestParam("number") String str)
	{
		return serv.getObject(str);
	}
}


