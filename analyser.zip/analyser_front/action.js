

function myFunction()
{
    var inp = document.getElementById("input").value;
    console.log(inp)
    var URL = "http://localhost:8080/morph_analyser?word="+encodeURIComponent(inp);
    jQuery.ajax({
        url: URL,
        success: function(data){
            console.log(data)
            document.getElementById('output').innerHTML = data['Answer'] + '\n'+data['Frag']
            //document.getElementById('textOut').innerHTML = data['Frag']
        },
         dataType: 'json'
    });
}
