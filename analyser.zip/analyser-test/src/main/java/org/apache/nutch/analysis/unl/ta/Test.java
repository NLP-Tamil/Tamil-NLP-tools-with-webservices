package org.apache.nutch.analysis.unl.ta;

import java.util.*;

public class Test {
    public static void main(String args[]) {
        Analyser analyser = new Analyser();
        ArrayList arr = analyser.onlineDictAnalyser("அம்மாவின்", "Tamil");
    }
}


