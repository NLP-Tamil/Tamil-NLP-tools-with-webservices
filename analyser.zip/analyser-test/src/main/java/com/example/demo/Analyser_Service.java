package com.example.demo;

import java.io.*; 
import java.util.*; 
import org.apache.nutch.analysis.unl.ta.Analyser;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

 @Service
public class Analyser_Service{
	 
	public JSONObject getObject(String str)
	{
		JSONObject obj = new JSONObject();
		
		Analyser analyser = new Analyser();
		ArrayList arr= analyser.onlineDictAnalyser(str, "Tamil");
		
		obj.put("Answer", arr.get(0));
		obj.put("Frag", arr.get(1));
		
		    return obj;
	
	}
}
	//மதுரையிலிருந்து
	//மதுரைக்கு

