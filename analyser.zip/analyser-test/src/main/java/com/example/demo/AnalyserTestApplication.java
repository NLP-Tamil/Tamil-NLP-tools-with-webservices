package com.example.demo;

import java.util.ArrayList;
import org.apache.nutch.analysis.unl.ta.Analyser;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.apache.nutch.analysis.unl.ta.Analyser;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.JSONArray;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
//@ComponentScan(basePackages={"com.*"})
public class AnalyserTestApplication extends SpringBootServletInitializer{


	public static void main(String[] args) {
		SpringApplication.run(AnalyserTestApplication.class, args);
		
	}
		
	
}
