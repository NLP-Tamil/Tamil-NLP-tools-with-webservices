package com.example;

import org.apache.nutch.analysis.unl.ta.Analyser;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class analyser_controller {
	
	@Autowired
	private Analyser_Service analys_service;

	@GetMapping(value = "hello_world")
	public JSONObject getString(@RequestParam("word") String str)
	{
		return analys_service.getObject(str);
	}
}
