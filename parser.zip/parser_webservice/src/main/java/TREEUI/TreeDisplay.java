package TREEUI;

import java.awt.*;
import javax.swing.*;
import java.util.*;


public class TreeDisplay extends JPanel
{
	public TreeDisplay()
	{
   	}

  public void paintComponent(Graphics g)
    {
		g.drawLine(0,0,900,200);
	}
}