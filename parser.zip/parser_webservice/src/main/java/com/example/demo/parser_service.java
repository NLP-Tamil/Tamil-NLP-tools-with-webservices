package com.example.demo;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import Parser.Parser;

@Service
public class parser_service {
	
	
	@SuppressWarnings("unchecked")
	public JSONObject getObject(String input)
	{
		JSONObject obj=new JSONObject();
		ParserUI pars=new ParserUI();
		Parser parser=new Parser();
		String output="";
		String temp = parser.DoPreprocess(input);
		
		if(temp!= null)
			output=pars.ParseSentence(input);
		else
			output=pars.ParseSentence(input);
		
		System.out.println("result: "+output);
		
		if(output==""|| output=="S(\n             )")
			output="சரியான வாக்கியம் அல்ல";
		
		obj.put("result",output);

	return obj;
	}


}
