package com.example.demo;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Generator_controller {
	
	@Autowired
	public Generator_service serv;
	
	@CrossOrigin(origins = "*", allowedHeaders="*" )
	@GetMapping("Generate")
	public JSONObject getResult(@RequestParam("sentence")String sentence1,@RequestParam("pos")String pos) throws Exception
	{
//		System.out.println(sentence1+" "+pos+" "+case1+" ");
//		case1=case1.replace(' ', '+');
//		System.out.println(sentence1+" "+pos+" "+case1+" ");
		return serv.getObject(sentence1,pos);
	}

}
