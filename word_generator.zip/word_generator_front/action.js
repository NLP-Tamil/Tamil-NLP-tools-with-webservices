

function myFunction()
{
    var inp = document.getElementById("input").value;
	    var inp2 = document.getElementById("input2").value;
	    
console.log(inp)
    var URL = "http://localhost:8080/Generate?sentence="+encodeURIComponent(inp)+'&pos='+encodeURIComponent(inp2);
    jQuery.ajax({
        url: URL,
        success: function(data){
            console.log(data)
            document.getElementById('textOut').innerHTML = data['Generated']
            // document.getElementById('json').innerHTML = JSON.stringify(data, undefined, 2)
        },
         dataType: 'json'
    });
}
