package com.example.demo;

import org.apache.nutch.analysis.unl.ta.Analyser;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class No_analyser_service {
	
	public JSONObject getNumber(String number)
	{
		JSONObject obj=new JSONObject();
		
	    String output = Analyser.analyseF(number.trim(), true);
	    System.out.println("value of output " + output);
	    
	    if(output.equals(""))
	    	output="தவறான உள்ளீடு";
	    
	    obj.put("result", output);
	    return obj;
	}

}
