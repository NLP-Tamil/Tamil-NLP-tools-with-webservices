package org1.apache.xml.security.keys.keyresolver;

public class KeyResolver {

}
