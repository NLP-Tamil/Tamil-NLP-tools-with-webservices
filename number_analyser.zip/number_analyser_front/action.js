

function myFunction()
{
    var inp = document.getElementById("input").value;
    console.log(inp)
    var URL = "http://localhost:8080/Number_analyser?number="+encodeURIComponent(inp);
    jQuery.ajax({
        url: URL,
        success: function(data){
            console.log(data)
            document.getElementById('textOut').innerHTML = data['result']
            // document.getElementById('json').innerHTML = JSON.stringify(data, undefined, 2)
        },
         dataType: 'json'
    });
}
