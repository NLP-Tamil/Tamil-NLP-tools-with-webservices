

function myFunction()
{
    var inp = document.getElementById("input").value;
    console.log(inp)
    var URL = "http://localhost:8080/lyric_analyse?word="+encodeURIComponent(inp);
    jQuery.ajax({
        url: URL,
        success: function(data){
            console.log(data)
            document.getElementById('textOut').innerHTML = data['result']
	console.log(Object.keys(data['result']).length)
var endRes;
	for(var i =0;i<Object.keys(data['result']).length;i++)
		endRes = endRes + 'Tamilword   :'+data['result'][i]['Tamilword   :']+'\n'+'	music------>   :'+data['result'][i]['	music------>   :']+'\n'+'	author----->   :'+data['result'][i]['	author----->   :']+'\n'+'	lyrics head--->  :'+data['result'][i]['	lyrics head--->  :']+'\n'+'	lSentence------>  :'+data['result'][i]['	lSentence------>  :']+'\n'
            // document.getElementById('json').innerHTML = JSON.stringify(data, undefined, 2)
	document.getElementById('textOut').innerHTML = endRes
        },
         dataType: 'json'
    });
}
