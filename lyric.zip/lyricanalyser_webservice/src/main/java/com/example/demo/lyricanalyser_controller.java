package com.example.demo;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.example.demo.lyricanalyser_Service;

@RestController
public class lyricanalyser_controller {
	@Autowired
	private lyricanalyser_service lyric_service;

	@CrossOrigin(origins="*",allowedHeaders="*")
	@GetMapping(value = "lyric_analyse")
	public JSONObject getString(@RequestParam("word") String str)
	{
		return lyric_service.getObject(str);
	}
	

	
}
