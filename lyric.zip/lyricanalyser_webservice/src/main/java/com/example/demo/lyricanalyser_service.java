package com.example.demo;

import java.util.ArrayList;
import java.util.Collection;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.stereotype.Service;

import lyricanalyser.LTravereseIndex;

@Service
public class lyricanalyser_service {
	@SuppressWarnings("unchecked")
	public JSONObject getObject(String str) {
		// TODO Auto-generated method stub
		
		JSONObject obj=new JSONObject();
		JSONObject obj2=new JSONObject();
		LTravereseIndex travereseIndex=new LTravereseIndex();
	  ArrayList results=travereseIndex.readLyricsIndex(str);
//	  System.out.println("string: "+results);
	  travereseIndex.display(results);
	
	  JSONArray arrobj = new JSONArray();
      int i=1;
	  for (Object s : results) {
          String[] getOutput = (String[]) s;     
          
          obj=null;
          obj=new JSONObject();
          obj.put("Tamilword   :", getOutput[0]);
          obj.put("\ttitle----->   :", getOutput[1]);
          obj.put("\tmusic------>   :", getOutput[2]);
          obj.put("\tauthor----->   :", getOutput[3]);
          obj.put("\tlyrics head--->  :", getOutput[4]);
          obj.put("\tlSentence------>  :", getOutput[5]);
         
//          obj2.put(i,obj);
          i++;
          arrobj.add(obj);
          
     
      }
	  obj2.put("result", arrobj);
		return obj2;
	}
}