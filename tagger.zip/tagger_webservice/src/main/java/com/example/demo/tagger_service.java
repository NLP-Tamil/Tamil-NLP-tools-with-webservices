package com.example.demo;

import java.io.UnsupportedEncodingException;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class tagger_service {
	
	@SuppressWarnings("unchecked")
	public JSONObject getTagAns(String input) throws UnsupportedEncodingException
	{
		Checktoken checktoken=new Checktoken();
		JSONObject obj =new JSONObject();
		Tagger.nexttoken="";
		Tagger.SecondToken=null;
		Tagger.ThirdToken=null;
		Tagger.FirstToken=null;
		Tagger.FourthToken=null;
		
	//	String str1 = new String(input.getBytes("ISO-8859-15"), "UTF-8");
//		String str1=new String(input.getBytes("ISO-8859-15"));
		//System.out.println(str1);
		
		String str1="";
		str1=checktoken.checktoken(input);
//		String str = new String(str1.getBytes("UTF-8"), "ISO-8859-15");
//		String str=new String(checktoken.checktoken(str1).getBytes("UTF-8"));
		System.out.println(str1);
		//System.out.println(new String(str1.getBytes("UTF-8")));
		
		obj.put("result",str1);

		return obj;
	}
	

}
