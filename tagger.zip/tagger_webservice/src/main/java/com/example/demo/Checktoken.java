package com.example.demo;
/****** Checktoken class  contains  removeall and checkfull methods
 String tokenizer is used to parse the file in to single token and process is done using above mentioned method **************

 Author 		:Dhinakaran .T
 Client 		:RCILTS
 Modify Date    :25.09.2002
 Anna University
 Copyright (c) 2002
 ************************/

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.System;
import java.io.*;
import java.sql.*;

/***Checktoken class  contains removeall and checkfull method
 String tokenizer is used to parse the file in to single token and process is done using above mentioned method ****/

public class Checktoken
{
	//Removekctp class  used to  Remove 'k' 'c' 't' 'p'
	Removekctp removeall=new Removekctp();

	//Checkfullitem class used to check all items (ie noun,verb,adverb,adjective,particle....)
	Checkfullitem checkfull=new Checkfullitem();

/*****************************************Default constructor******************************/

	Checktoken()
	{	}

/******************checktoken method  used to  parse the file using  delimiters
* @param string -java.lang.string

**************/

	public String checktoken(String string)
 	{
		String output="";
/*****************using String Tokenizer to parse the String *********/
		System.out.println(" Calling checktoken: "+ string);
   	   Tagger.stringtoken =new StringTokenizer(string,":'\f' '\n' '\n\n\n' ' ' ; < > \" ( ) /  , '  ' - ! ? _ '\t' ");
   	   while(Tagger.stringtoken.hasMoreTokens())
       {          
    	   System.out.println("tokenizer string:"+Tagger.nexttoken);

      	  //System.out.println(Tagger.stringtoken.nextToken());
    	   //System.out.println("tagger.count:"+Tagger.count+"\n");
    	   try
     	  {
      		(Tagger.count)++;
      		
            Tagger.nexttoken =Tagger.stringtoken.nextToken();
            System.out.println("tokenizer string:"+Tagger.nexttoken);
            if(Tagger.count==1)
            {

/***************** to convert string into bytes**************************/

            Tagger.FirstToken=tabconvert2.convert(Tagger.nexttoken);
			if (Tagger.stringtoken.hasMoreTokens())
   		  	{
            	 Tagger.count++;
            	 Tagger.nexttoken=Tagger.stringtoken.nextToken();
           		 Tagger.SecondToken=tabconvert2.convert(Tagger.nexttoken);
	       		 if (Tagger.stringtoken.hasMoreTokens())
          	     {
           			 Tagger.count++;
           			 Tagger.nexttoken=Tagger.stringtoken.nextToken();
           			 Tagger.ThirdToken=tabconvert2.convert(Tagger.nexttoken);

           			 //removeall method  used to  Remove 'k' 'c' 't' 'p'
                     output+=removeall.removeall();
            	 }
            	 else
                 {
               	 	Tagger.FirstToken=Tagger.FirstToken;

               	 	//removeall method  used to  Remove 'k' 'c' 't' 'p'
               	 output+=removeall.removeall();
               		Tagger.FirstToken=Tagger.SecondToken;

               		//removeall method  used to  Remove 'k' 'c' 't' 'p'
                    output+=removeall.removeall();
           		 }
	       		
            }
            else
            {
			  //checkfull method used to check all items (ie noun,verb,adverb,adjective,particle....)
//              System.out.println("first check");
//            	System.out.println("123");
            	output+=checkfull.checkfull();
           	}
//			System.out.println("2 check");
//			output+=checkfull.checkfull();//by NLP
	     }
         else if(Tagger.count>3)
       	 {
       		  if(Tagger.stringtoken.hasMoreTokens())
        	  {
        			 Tagger.FirstToken=Tagger.SecondToken;
            		 Tagger.SecondToken=Tagger.ThirdToken;
            		 Tagger.ThirdToken=tabconvert2.convert(Tagger.nexttoken);

            		 //removeall method  used to  Remove 'k' 'c' 't' 'p'
         		 	 output+=removeall.removeall();
        	  }
        	  else
         	  {
//        		  System.out.println("last else in checktoken:\n");
        //		  String str="";
        		  Tagger.FirstToken=Tagger.SecondToken;

   	 	   //checkfull method used to check all items (ie noun,verb,adverb,adjective,particle....)
//        		  System.out.println("3 check");
        		  output+=checkfull.checkfull();																																																																																																																																													
			   Tagger.FirstToken=Tagger.ThirdToken;

//			   System.out.println("4 check");
			   //checkfull method used to check all items (ie noun,verb,adverb,adjective,particle....)
			   output+=checkfull.checkfull();
    	       Tagger.FirstToken=tabconvert2.convert(Tagger.nexttoken);

//    	       System.out.println("5 check");																																																																																																																																						
    	       //checkfull method used to check all items (ie noun,verb,adverb,adjective,particle....)
    	       output+=checkfull.checkfull();
         
//    	       System.out.println("output: "+output);
         	  }			
       }
     	  }
         catch(Exception e)
         {
         
        	 System.out.println(e);
        	 // Tagger.textarea.setText(tabconvert2.revert(Tagger.FirstToken)+"  "+"<unknown>"+"\n");
         }
  }
//       System.out.println("return output: in checktoken");
       
  return output;
 }
}